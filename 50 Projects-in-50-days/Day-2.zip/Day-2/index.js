const previous = document.getElementById("previous");
const next = document.getElementById("next");
let containers = document.querySelectorAll(".number");
let count = 0;

let w = 0;
let crossbar = document.querySelector(".crossBarActive")

// if(count > containers.length -1) { count = 1}

console.log(containers)
next.addEventListener("click", function(e){
    console.log(count)
    if(count > containers.length -1){
        count = 1
    } else {
        count++

        w+=50
    }
    containers[count].classList.add('active');
    crossbar.style.width = w + '%';
     
    
})

previous.addEventListener("click", function(){
    containers[count].classList.remove('active')
    console.log(count)
    count--
    w-=50
    crossbar.style.width = w + '%';
    if(count < 0) {
        count = 0
    }

})
